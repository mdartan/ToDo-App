from django.urls import path
from . import views


urlpatterns = [
    path('', views.home, name="home"),
    path('update/<str:pk_id>/', views.update, name="update"),
    path('delete/<str:pk_id>/', views.delete, name="delete"),
    path('deleted/<str:pk_id>/', views.deleted, name="deleted"),
    path('singin', views.singin, name="singin"),
    path('logout', views.logout_user, name="logout"),
    path('Statistics', views.statistics, name="Statistics"),
    path('insert', views.insert, name="insert"),
    path('upload', views.upload, name="upload"),
    path('export', views.export, name="export"),
    path('profile', views.profile, name="profile"),
]