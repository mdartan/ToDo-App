from django.db import models
from django.contrib import admin
from django.contrib.auth import authenticate
from django.contrib.auth.models import User

# Create your models here.
class todo(models.Model):
    
    STATUS = (
			('Complete', 'Complete'),
			('Not Complete', 'Not Complete'),
			) 
    
    users = models.ManyToManyField(User, related_name='reports')
    ToDo = models.CharField(max_length=200, null=True)
    Status = models.CharField(max_length=200, null=True, choices=STATUS)
    Created = models.DateTimeField(auto_now_add=True, null=True)
    Updated = models.DateTimeField(auto_now_add=True, null=True)

    def __str__(self):
        return self.ToDo

