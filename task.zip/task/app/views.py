import csv, io
import imp  
from pyexpat.errors import messages
from turtle import st
from django.shortcuts import redirect, render
from django.http import HttpResponseRedirect, FileResponse
from .models import todo
from .forms import TodoForm
from datetime import datetime
from django.contrib.auth import authenticate, login, logout
from reportlab.pdfgen import canvas
from reportlab.lib.units import inch
from reportlab.lib.pagesizes import letter 
# Create your views here.

def singin(request):
    user = request.user.is_authenticated
    if user == True:
        todolist = todo.objects.all()
        return redirect("../", {'todolist': todolist})
    if user == False:
        messages = False
        if request.method == "POST":
            username = request.POST['username']
            password = request.POST['password']
            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                todolist = todo.objects.all()
                return redirect("../", {'todolist': todolist})
            else:
                messages = True
                return render(request, "app/login.html", {'messages': messages})
        else:
            return render(request, "app/login.html")

def logout_user(request):
    logout(request) 
    return redirect('../singin') 

def profile(request):
    user = request.user.is_authenticated
    if user == True:
        todolist = todo.objects.all()
        return render(request, "app/profile.html", {'todolist': todolist, 'title': 'Profile | ToDo App'})
    if user == False:
        return redirect('../singin')

def home(request):
    user = request.user.is_authenticated
    if user == True:
        todolist = todo.objects.all()
        return render(request, "app/dashboard.html", {'todolist': todolist, 'title': 'Dashboard | ToDo App'})
    if user == False:
        return redirect('../singin')

def update(request, pk_id):
    user = request.user.is_authenticated
    if user == False:
        return redirect('../singin')
    else:
        id = pk_id
        todolist = todo.objects.get(id=id)
        states = todolist.Status
        dat = datetime.now()
        if states == 'Complete':
            todo.objects.filter(id=id).update(Status='Not Complete', Updated=dat)
            return HttpResponseRedirect('../../')
        elif states == 'Not Complete':
            todo.objects.filter(id=id).update(Status='Complete', Updated=dat)
            return HttpResponseRedirect('../../')
        else:
            return redirect('../../')
    

def delete(request, pk_id):
    user = request.user.is_authenticated
    if user == False:
        return redirect('../singin')
    else:
        deleting = False
        id = pk_id
        deleting = True
        todolist = todo.objects.all()
        return render(request, "app/dashboard.html", {'todolist': todolist, 'deleting': deleting, 'id': id, 'title': 'Dashboard | ToDo App'})

def deleted(request, pk_id):
    user = request.user.is_authenticated
    if user == False:
        return redirect('../singin')
    else:
        deleting = False
        id = pk_id
        todolist = todo.objects.get(id=id).delete()
        todolist = todo.objects.all()
        return redirect('../../')
    
def statistics(request):
    user = request.user.is_authenticated
    if user == False:
        return redirect('../singin')
    else:
        complete = todo.objects.filter(Status='Complete').count()
        uncomplete = todo.objects.filter(Status='Not Complete').count()
        return render(request, "app/statistics.html", {'complete': complete,'uncomplete': uncomplete, 'title': 'Statistics | ToDo App'})
    
def insert(request):
    user = request.user.is_authenticated
    if user == False:
        return redirect('../singin')
    else:
        submitted = False
        if request.method =="POST":
            form = TodoForm(request.POST)
            if form.is_valid():
                form.save()
                return HttpResponseRedirect('/insert?submitted=True')
        else:
            form = TodoForm
            if 'submitted' in request.GET:
                submitted = True
        return render(request, "app/insert.html", {'form':form,'submitted':submitted, 'title': 'Create | ToDo App'})

def upload(request):
    user = request.user.is_authenticated
    if user == False:
        return redirect('../singin')
    else:
        f = False
        done = False
        if request.method == "POST":
            fil = request.FILES['file']
            if not fil.name.endswith('.csv'):
                f = True
                return render(request, "app/import.html", {'f': f, 'title': 'Import | ToDo App'})
            else:
                data_set = fil.read().decode("utf-8")
                io_string = io.StringIO(data_set)
                next(io_string)
                for column in csv.reader(io_string, delimiter=',', quotechar="|"):
                    todo.objects.create(
                        ToDo = column[0],
                        Status = column[1],
                    )
                done = True
                return render(request, "app/import.html", {'done': done, 'title': 'Import App | ToDo App'})
        else:
            return render(request, "app/import.html", {'title': 'Import | ToDo App'})
        
def export(request):
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=letter, bottomup=0)
    textob = c.beginText()
    textob.setTextOrigin(inch, inch)
    textob.setFont("Helvetica", 14)

    todolist = todo.objects.all()
    lines = []
    for todol in todolist:
        lines.append(todol.ToDo)
        lines.append(todol.Status)
        lines.append('__________________')

    for line in lines:
        textob.textLine(line)
    c.drawText(textob)
    c.showPage()
    c.save()
    buf.seek(0)
    return FileResponse(buf, as_attachment=True, filename='export.pdf')
